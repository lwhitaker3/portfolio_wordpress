<nav class="navbar navbar-expand-md" style= "margin-bottom:50px">
  <a class="navbar-brand" href="#">
    <div id="logo-wrapper">
      <?php get_template_part('templates/svg/logo'); ?>
    </div>
  </a>
</nav>
