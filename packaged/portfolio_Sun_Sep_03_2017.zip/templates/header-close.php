<nav class="navbar navbar-expand-md fixed-top">
  <a class="navbar-brand" href="#">
    <div id="logo-wrapper">
      <?php get_template_part('templates/svg/logo'); ?>
    </div>
  </a>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link close-icon" href="#work"><i class="icon-close"></i></a>
    </li>
  </ul>
</nav>
