<?php get_template_part('templates/content-project', get_post_type()); ?>
